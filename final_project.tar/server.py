'''Server for emotiondetector'''
from flask import Flask, render_template, request
from EmotionDetection.emotion_detection import emotion_detector

app = Flask("emotionDetector")
@app.route("/emotionDetector")
def sent_analyzer():
    '''Parse the json response to formated string.'''
    text_to_analyze = request.args.get('textToAnalyze')
    response = emotion_detector(text_to_analyze)

    if 'None' in response:
        return 'Invalid text! Please try again!.'
    text = "For the given statement, the system response is"
    count = 0

    for emotion, score in response.items():
        if count == len(response) - 3:
            text = text + ' "' +  emotion + '": ' + str(score) + ' and'
        elif count == len(response) - 2:
            text = text + ' "' +  emotion + '": ' + str(score) + '.'
            text = text + ' The dominant emotion is "' + response['dominant_emotion'] + '".'
            break
        else:
            text = text + ' "' +  emotion + '": ' + str(score) + ','
        count += 1
    return text
@app.route("/")
def render_index_page():
    '''Render index page using the template.'''
    return render_template('index.html')

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
